# Security Policy

You can find this library's <a href="https://crankyoldgit.github.io/IRremoteESP8266/SECURITY">Security Policy</a> and contact procedure at https://crankyoldgit.github.io/IRremoteESP8266/SECURITY
